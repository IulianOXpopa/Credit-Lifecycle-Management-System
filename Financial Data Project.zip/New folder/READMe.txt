Bază de date pentru evidența creditelor acordate de o bancă

Popa Florin Iulian

1. Descrierea Bazei de Date
Proiectul implementează un sistem informatic complet pentru gestionarea activității de
creditare, utilizând o bază de date relațională MySQL și o interfață web PHP. Baza de date
(banca_db) este structurată pe 4 tabele principale, normalizate pentru a asigura
integritatea datelor:
• Tabela clienti: Stochează datele de identificare și financiare (KYC). Este
proiectată dual pentru a gestiona atât Persoane Fizice (CNP, Prenume, Angajator,
Salariu), cât și Persoane Juridice (CUI, Reg. Com, Cifră Afaceri, Profit). Include
câmpuri pentru stocarea documentelor scanate și a elementelor de identitate
vizuală (foto, semnătură).
• Tabela credite: Reține contractele de credit interne (Suma, Dobânda, Perioada,
Tip Dobândă), fiind legată de tabela clienti prin cheie externă (client_id).
• Tabela scadentar: Conține graficul de rambursare generat algoritmic. Fiecare rată
are status, dată scadență, penalități calculate și zile de întârziere. Este legată de
tabela credite prin credit_id.
• Tabela credite_externe: O replică simplificată a structurii Biroului de Credit,
reținând expunerea clienților la alte instituții financiare pentru calculul gradului de
îndatorare.
Relații: Sistemul utilizează relații de tip One-to-Many (Un client poate avea mai multe
credite; Un credit are mai multe rate în scadențar).
2. Prelucrări și Funcționalități Implementate
Aplicația realizează următoarele procesări automate de date:
• Procesul de Înrolare (KYC): Colectare diferențiată a datelor (PF vs PJ), upload
documente justificative pe server și generare automată de date demo (Series CI,
Venituri istorice).
• Scoring și Eligibilitate: Algoritm de verificare a eligibilității înainte de acordarea
creditului. Sistemul interoghează automat baza de date pentru incidente istorice
(Blacklist) și calculează gradul de îndatorare (limită 40% conf. normelor BNR),
luând în calcul și ratele externe.
• Generator de Credite: Calcul automat al scadențarului (metoda anuității) cu
generarea ratelor lunare și distribuirea aleatorie a zilelor de scadență (zilele 1-28 ale
lunii).
• Gestiunea Plăților și Restanțelor:
o Mecanism FIFO (First In, First Out) la plată: sistemul obligă achitarea celei
mai vechi restanțe înainte de rata curentă.
o Calcul dinamic al penalităților (0.1% / zi) și al zilelor de întârziere.
• Politica de Risc (Blacklist): Identificarea automată a clienților rău-platnici (>60 zile
întârziere) și aplicarea unei perioade de interdicție (cooling-off) de 4 ani de la
ultimul incident.
3. Cerințe Realizate vs. Nerealizate
Cerințe Realizate (100% din temă): Evidența separată a persoanelor fizice și juridice
(date specifice reținute corect). Cont client complet cu istoric, venituri și credite externe.
Plan de rambursare (scadențar) care scade soldul la plată. Calcul automat al penalităților
și zilelor de întârziere. Înregistrarea în baza de date a rău-platnicilor (Blacklist) dacă
întârzierea > 60 zile. Evidența creditelor multiple (la aceeași bancă sau bănci externe).
Interfață web funcțională (PHP) cu căutare globală și dashboard financiar.
